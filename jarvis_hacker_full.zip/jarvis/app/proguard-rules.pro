# Keep ONNX, Chaquopy, Room
-keep class ai.onnxruntime.** { *; }
-keep class com.chaquo.python.** { *; }
-keep class androidx.room.** { *; }
-dontwarn **
