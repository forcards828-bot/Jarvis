package com.jarvis.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class STTManager(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening

    private val _transcript = MutableStateFlow("")
    val transcript: StateFlow<String> = _transcript

    var onResult: ((String) -> Unit)? = null
    var onError: ((String) -> Unit)? = null
    var onReady: (() -> Unit)? = null

    fun startListening(hint: String = "en-IN") {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError?.invoke("Speech not available on this Xiaomi - install Google App")
            return
        }
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer?.setRecognitionListener(internalListener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            // Support Hinglish - we hint both
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, hint)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, hint)
            putExtra(RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES, arrayListOf("en-IN", "hi-IN", "en-US"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Xiaomi specific: enable offline if possible
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
        }
        _isListening.value = true
        recognizer?.startListening(intent)
    }

    fun stop() {
        try { recognizer?.stopListening(); recognizer?.cancel(); recognizer?.destroy() } catch (_: Exception) {}
        _isListening.value = false
    }

    private val internalListener = object : RecognitionListener {
        override fun onReadyForSpeech(p0: Bundle?) { onReady?.invoke() }
        override fun onBeginningOfSpeech() { }
        override fun onRmsChanged(p0: Float) { }
        override fun onBufferReceived(p0: ByteArray?) { }
        override fun onEndOfSpeech() { _isListening.value = false }
        override fun onError(code: Int) {
            _isListening.value = false
            val msg = when(code) {
                SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that, boss"
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timeout"
                SpeechRecognizer.ERROR_NETWORK -> "No internet for STT - switching to offline"
                else -> "STT error $code"
            }
            Log.w("JarvisSTT", msg)
            onError?.invoke(msg)
        }
        override fun onResults(bundle: Bundle?) {
            _isListening.value = false
            val res = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = res?.firstOrNull() ?: ""
            _transcript.value = text
            Log.i("JarvisSTT", "Heard: $text")
            if (text.isNotBlank()) onResult?.invoke(text)
        }
        override fun onPartialResults(bundle: Bundle?) {
            val res = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            _transcript.value = res?.firstOrNull() ?: ""
        }
        override fun onEvent(p0: Int, p1: Bundle?) { }
    }

    fun destroy() = stop()
}
