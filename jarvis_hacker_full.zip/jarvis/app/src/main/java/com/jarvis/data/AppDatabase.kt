package com.jarvis.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "execution_logs")
data class ExecutionLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val type: String, // WAKE, STT, SEARCH, YOUTUBE, PYTHON, CALL, etc
    val query: String,
    val tool: String = "",
    val status: String, // SUCCESS, FAIL, FIXING
    val durationMs: Long = 0,
    val error: String = "",
    val outputSnippet: String = ""
)

@Entity(tableName = "python_tools")
data class PythonTool(
    @PrimaryKey val name: String,
    val fileName: String,
    val version: String = "1.0",
    val enabled: Boolean = true,
    val permissions: String = "", // json list
    val installedAt: Long = System.currentTimeMillis(),
    val lastRunAt: Long = 0
)

@Entity(tableName = "conversation")
data class ConversationTurn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val role: String, // user, model
    val text: String,
    val selectedIndex: Int = -1
)

@Dao
interface LogDao {
    @Query("SELECT * FROM execution_logs ORDER BY timestamp DESC LIMIT 100")
    fun getLogsFlow(): Flow<List<ExecutionLog>>
    @Query("SELECT * FROM execution_logs ORDER BY timestamp DESC LIMIT 100")
    suspend fun getLogs(): List<ExecutionLog>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: ExecutionLog)
    @Query("DELETE FROM execution_logs")
    suspend fun clear()
}

@Dao
interface ToolsDao {
    @Query("SELECT * FROM python_tools")
    fun getToolsFlow(): Flow<List<PythonTool>>
    @Query("SELECT * FROM python_tools")
    suspend fun getAll(): List<PythonTool>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tool: PythonTool)
    @Query("DELETE FROM python_tools WHERE name = :name")
    suspend fun delete(name: String)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversation ORDER BY timestamp DESC LIMIT 20")
    suspend fun getRecent(): List<ConversationTurn>
    @Insert
    suspend fun insert(turn: ConversationTurn)
    @Query("DELETE FROM conversation")
    suspend fun clear()
}

@Database(entities = [ExecutionLog::class, PythonTool::class, ConversationTurn::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun logDao(): LogDao
    abstract fun toolsDao(): ToolsDao
    abstract fun conversationDao(): ConversationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "jarvis_hacker.db")
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
