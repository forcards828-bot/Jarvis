package com.jarvis.router

import android.content.Context
import android.util.Log
import com.jarvis.data.SecureKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient(private val context: Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    companion object {
        private const val GEMINI_URL_FLASH = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
        private const val SYSTEM_PROMPT = """
You are JARVIS, a personal hacker-type AI assistant for Xiaomi Note 13 5G, personal sideload, free build.
- Be concise, hacker-terminal style but helpful.
- If user says "Do as Directed" or "summarize", produce sharp summary with bullet points and sources if provided.
- Understand Hinglish (Hindi + English mix).
- For phone actions, output intent JSON, not chat.
- Never hallucinate live news - say UNKNOWN if not sure.
- For python error fixing, output corrected python code only inside ```python block.
"""
    }

    suspend fun chat(userText: String, history: List<Pair<String, String>> = emptyList()): String = withContext(Dispatchers.IO) {
        val key = SecureKeys.getGemini(context)
        if (key.isBlank()) return@withContext "Gemini API key missing. Add in Settings, boss."
        try {
            val contents = JSONArray()
            // Add system as first user message (Gemini 1.5 Flash doesn't have system role in v1beta)
            val sysObj = JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
            }
            contents.put(sysObj)
            val modelAck = JSONObject().apply {
                put("role", "model")
                put("parts", JSONArray().put(JSONObject().put("text", "Understood. JARVIS online. Hacker mode active.")))
            }
            contents.put(modelAck)
            // History
            history.takeLast(6).forEach { (role, text) ->
                contents.put(JSONObject().apply {
                    put("role", if (role == "user") "user" else "model")
                    put("parts", JSONArray().put(JSONObject().put("text", text)))
                })
            }
            // Current
            contents.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", userText)))
            })

            val bodyJson = JSONObject().put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 1024))

            val req = Request.Builder()
                .url("$GEMINI_URL_FLASH?key=$key")
                .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val resp = client.newCall(req).execute()
            val respBody = resp.body?.string() ?: return@withContext "Empty response from Gemini"
            if (!resp.isSuccessful) {
                Log.e("JarvisGemini", "HTTP ${resp.code} $respBody")
                return@withContext when {
                    resp.code == 429 -> "Quota exceeded, boss. Free tier limit. Wait 1 min."
                    resp.code == 400 && respBody.contains("API_KEY") -> "Invalid Gemini key"
                    else -> "Gemini error: ${resp.code}"
                }
            }
            val json = JSONObject(respBody)
            val candidates = json.optJSONArray("candidates") ?: return@withContext "No candidates"
            val first = candidates.optJSONObject(0) ?: return@withContext "No response"
            val content = first.optJSONObject("content") ?: return@withContext "No content"
            val parts = content.optJSONArray("parts") ?: return@withContext "No parts"
            val text = parts.optJSONObject(0)?.optString("text") ?: "No text"
            text
        } catch (e: Exception) {
            Log.e("JarvisGemini", "Chat failed", e)
            "Error: ${e.message} - Self test: Check internet on your Note 13 5G"
        }
    }

    suspend fun fixPython(code: String, error: String): String = withContext(Dispatchers.IO) {
        val prompt = """
Fix this python code for Android Chaquopy (pure python only, no selenium/playwright/chromedriver).
Error:
$error

Code:
```python
$code
```

Rules:
- Only use requests, bs4, json, os, re, datetime, python-dateutil (already installed)
- Do NOT use selenium, playwright, lxml with C libs unless pure
- Keep function signatures
- Output fixed code only in ```python block
- Self-test: ensure no syntax error
"""
        val result = chat(prompt)
        // Extract python block
        val regex = Regex("```python\\s*([\\s\\S]*?)```")
        val match = regex.find(result)
        return@withContext match?.groupValues?.get(1)?.trim() ?: result
    }

    suspend fun summarize(text: String): String {
        return chat("Do as Directed - Summarize this sharply in hacker terminal bullet points, keep key facts, add source credibility if any:\n\n$text")
    }
}
