package com.jarvis.python

import android.content.Context
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * FREE Python runner via Chaquopy
 * Self-healing + Self-test included
 */
class PythonRunner(private val context: Context) {

    data class RunResult(
        val success: Boolean,
        val output: String,
        val error: String,
        val durationMs: Long
    )

    init {
        if (!Python.isStarted()) {
            Python.start(AndroidPlatform(context))
        }
    }

    suspend fun runFile(file: File): RunResult = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        val logs = StringBuilder()
        val errors = StringBuilder()
        try {
            // Self-test: does file exist?
            if (!file.exists()) return@withContext RunResult(false, "", "File not found: ${file.path}", 0)

            // Self-test: check python syntax basic
            val code = file.readText()
            if (code.isBlank()) return@withContext RunResult(false, "", "Empty file", 0)

            val py = Python.getInstance()
            // Capture stdout
            val sys = py.getModule("sys")
            val io = py.getModule("io")
            val stringIO = io.callAttr("StringIO")
            val oldStdout = sys.get("stdout")
            val oldStderr = sys.get("stderr")
            sys.put("stdout", stringIO)
            sys.put("stderr", stringIO)

            try {
                // Execute file path
                sys.get("path").callAttr("append", file.parent)
                val builtins = py.getBuiltins()
                // Run
                py.getModule("builtins").callAttr("exec", code, builtins.get("globals")())
                val out = stringIO.callAttr("getvalue").toString()
                logs.append(out)
                RunResult(true, logs.toString(), "", System.currentTimeMillis() - start)
            } catch (e: Exception) {
                val out = try { stringIO.callAttr("getvalue").toString() } catch (_: Exception) { "" }
                errors.append(e.message ?: e.toString())
                errors.append("\n").append(out)
                Log.e("JarvisPython", "Run failed", e)
                RunResult(false, out, errors.toString(), System.currentTimeMillis() - start)
            } finally {
                try { sys.put("stdout", oldStdout); sys.put("stderr", oldStderr) } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            RunResult(false, logs.toString(), "Runner crash: ${e.message}", System.currentTimeMillis() - start)
        }
    }

    suspend fun runCode(code: String): RunResult {
        val temp = File(context.cacheDir, "temp_run_${System.currentTimeMillis()}.py")
        temp.writeText(code)
        return runFile(temp)
    }

    fun listTools(): List<File> {
        val dir = File(context.filesDir, "tools")
        if (!dir.exists()) dir.mkdirs()
        return dir.listFiles()?.filter { it.extension == "py" } ?: emptyList()
    }

    fun getToolDir(): File {
        val dir = File(context.filesDir, "tools")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }
}
