package com.jarvis.actions

import android.content.Context
import android.os.Environment
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FileActions(private val context: Context) {

    private val searchRoots = listOf(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
        context.getExternalFilesDir(null)
    ).filterNotNull()

    suspend fun findFile(query: String): List<File> = withContext(Dispatchers.IO) {
        val results = mutableListOf<File>()
        val lower = query.lowercase()
        try {
            for (root in searchRoots) {
                if (!root.exists()) continue
                root.walkTopDown().maxDepth(4).forEach { file ->
                    if (results.size >= 20) return@forEach
                    if (file.name.lowercase().contains(lower)) results.add(file)
                }
            }
        } catch (e: Exception) {
            Log.e("JarvisFile", "Search fail", e)
        }
        results
    }

    suspend fun readTextFile(path: String): String = withContext(Dispatchers.IO) {
        try {
            val file = File(path)
            if (!file.exists()) {
                // Try search
                val found = findFile(File(path).name).firstOrNull()
                if (found != null && found.exists()) return@withContext found.readText().take(10000)
                return@withContext "File not found: $path"
            }
            if (file.length() > 2_000_000) return@withContext "File too large >2MB"
            file.readText().take(10000)
        } catch (e: Exception) {
            "Error reading file: ${e.message}"
        }
    }

    fun listDownloads(): List<File> {
        return try {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.listFiles()?.take(20) ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }
}
