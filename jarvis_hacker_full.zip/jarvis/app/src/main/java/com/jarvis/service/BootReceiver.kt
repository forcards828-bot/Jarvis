package com.jarvis.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log

/**
 * For Xiaomi Note 13 5G - Auto-start after reboot
 * Xiaomi blocks by default, but we try + backup restore
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.i("JarvisBoot", "Boot action: $action")
        if (action == Intent.ACTION_BOOT_COMPLETED || 
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON") {
            
            try {
                val serviceIntent = Intent(context, JarvisService::class.java).apply {
                    putExtra("from_boot", true)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
                Log.i("JarvisBoot", "JARVIS auto-started after boot - Xiaomi")
            } catch (e: Exception) {
                Log.e("JarvisBoot", "Auto-start failed - Xiaomi blocked, user must open app once", e)
            }
        }
    }
}
