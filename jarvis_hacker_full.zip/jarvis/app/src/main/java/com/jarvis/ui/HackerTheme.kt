package com.jarvis.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

// Hacker Theme - As user asked - Good Hacker Type Interface
object HackerColors {
    val Background = Color(0xFF000000)
    val Surface = Color(0xFF0A0A0A)
    val Card = Color(0xFF111111)
    val Green = Color(0xFF00FF41)
    val GreenDim = Color(0xFF00CC33)
    val GreenGlow = Color(0xFF00FF41).copy(alpha = 0.3f)
    val Red = Color(0xFFFF0040)
    val Cyan = Color(0xFF00FFFF)
    val Gray = Color(0xFF888888)
    val White = Color(0xFFE0E0E0)
}

@Composable
fun HackerTheme(content: @Composable () -> Unit) {
    val darkScheme = darkColorScheme(
        primary = HackerColors.Green,
        onPrimary = Color.Black,
        background = HackerColors.Background,
        onBackground = HackerColors.Green,
        surface = HackerColors.Surface,
        onSurface = HackerColors.White,
        error = HackerColors.Red
    )
    MaterialTheme(
        colorScheme = darkScheme,
        typography = Typography().copy(
            bodyMedium = Typography().bodyMedium.copy(fontFamily = FontFamily.Monospace),
            titleMedium = Typography().titleMedium.copy(fontFamily = FontFamily.Monospace)
        ),
        content = content
    )
}
