package com.jarvis.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PhoneActions(private val context: Context) {

    data class ContactResult(val name: String, val number: String)

    suspend fun searchContacts(query: String): List<ContactResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<ContactResult>()
        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$query%"),
                null
            )
            cursor?.use {
                while (it.moveToNext() && results.size < 10) {
                    val name = it.getString(0) ?: "Unknown"
                    val number = it.getString(1) ?: ""
                    results.add(ContactResult(name, number))
                }
            }
        } catch (e: Exception) {
            Log.e("JarvisPhone", "Contact search fail", e)
        }
        results
    }

    fun callContact(number: String): Boolean {
        return try {
            // For personal sideload - direct call allowed with CALL_PHONE permission
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            try {
                val dial = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(dial)
                true
            } catch (e2: Exception) {
                Log.e("JarvisPhone", "Call failed", e2)
                false
            }
        }
    }

    fun openApp(appName: String): Boolean {
        val pm = context.packageManager
        val mapping = mapOf(
            "youtube" to "com.google.android.youtube",
            "yt" to "com.google.android.youtube",
            "instagram" to "com.instagram.android",
            "insta" to "com.instagram.android",
            "whatsapp" to "com.whatsapp",
            "chrome" to "com.android.chrome",
            "maps" to "com.google.android.apps.maps",
            "map" to "com.google.android.apps.maps",
            "spotify" to "com.spotify.music",
            "gmail" to "com.google.android.gm",
            "camera" to "com.android.camera2",
            "settings" to "com.android.settings"
        )
        val lower = appName.lowercase()
        var pkg: String? = null
        for ((k, v) in mapping) if (lower.contains(k)) { pkg = v; break }

        return try {
            if (pkg != null) {
                val launch = pm.getLaunchIntentForPackage(pkg)
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launch)
                    return true
                }
            }
            // Fallback: search launchable
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val apps = pm.queryIntentActivities(intent, 0)
            val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(lower) }
            if (match != null) {
                val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                launch?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch!!)
                return true
            }
            false
        } catch (e: Exception) {
            Log.e("JarvisPhone", "Open app fail $appName", e)
            false
        }
    }

    fun openSettings(): Boolean {
        return try {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            true
        } catch (_: Exception) { false }
    }
}
