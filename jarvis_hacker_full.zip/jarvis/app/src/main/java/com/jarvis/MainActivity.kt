package com.jarvis

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.jarvis.service.JarvisService
import com.jarvis.ui.HackerColors
import com.jarvis.ui.HackerTheme
import com.jarvis.ui.MainScreen
import com.jarvis.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    
    @OptIn(ExperimentalPermissionsApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Auto-start service as user wants Hey Jarvis only
        try {
            val serviceIntent = Intent(this, JarvisService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (_: Exception) {}

        setContent {
            HackerTheme {
                var selectedTab by remember { mutableStateOf(0) }
                val tabs = listOf("JARVIS", "TOOLS", "ACTIVITY", "SETTINGS")
                
                val permissionsState = rememberMultiplePermissionsState(
                    permissions = listOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.POST_NOTIFICATIONS
                    )
                )
                
                LaunchedEffect(Unit) {
                    if (!permissionsState.allPermissionsGranted) {
                        permissionsState.launchMultiplePermissionRequest()
                    }
                }

                Scaffold(
                    containerColor = Color.Black,
                    topBar = {
                        TabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = Color.Black,
                            contentColor = HackerColors.Green
                        ) {
                            tabs.forEachIndexed { index, title ->
                                Tab(
                                    selected = selectedTab == index,
                                    onClick = { selectedTab = index },
                                    text = { 
                                        Text(
                                            "> $title", 
                                            fontFamily = FontFamily.Monospace, 
                                            fontSize = 10.sp,
                                            color = if (selectedTab == index) HackerColors.Green else HackerColors.Gray
                                        ) 
                                    }
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(modifier = Modifier.padding(padding).fillMaxSize().background(Color.Black)) {
                        when (selectedTab) {
                            0 -> MainScreen()
                            1 -> ToolsScreen()
                            2 -> ActivityScreen()
                            3 -> SettingsScreen()
                        }
                    }
                }
            }
        }
    }
}

// Placeholder Tools Screen - Upload via Settings, list here
@androidx.compose.runtime.Composable
fun ToolsScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var tools by androidx.compose.runtime.remember { mutableStateOf(listOf<java.io.File>()) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        tools = com.jarvis.python.PythonRunner(context).listTools()
    }
    androidx.compose.foundation.layout.Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)
    ) {
        androidx.compose.material3.Text("> INSTALLED PYTHON TOOLS", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))
        if (tools.isEmpty()) {
            androidx.compose.material3.Text("> No tools. Go to SETTINGS -> Upload File", color = HackerColors.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        } else {
            tools.forEach { f ->
                androidx.compose.material3.Text("> ${f.name} | ${f.length()/1024}KB | Ready", color = HackerColors.White, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            }
        }
    }
}

@androidx.compose.runtime.Composable
fun ActivityScreen() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var logs by androidx.compose.runtime.remember { mutableStateOf(listOf<com.jarvis.data.ExecutionLog>()) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        val db = com.jarvis.data.AppDatabase.get(context)
        logs = db.logDao().getLogs()
    }
    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)) {
        item {
            androidx.compose.material3.Text("> FULL ACTIVITY TRANSPARENCY", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        items(logs.size) { i ->
            val log = logs[i]
            androidx.compose.foundation.layout.Column(modifier = Modifier.padding(vertical = 4.dp)) {
                androidx.compose.material3.Text("${log.timestamp} | ${log.type} | ${log.status}", color = HackerColors.Cyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                androidx.compose.material3.Text(log.query, color = HackerColors.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                if (log.error.isNotBlank()) androidx.compose.material3.Text("ERROR: ${log.error}", color = HackerColors.Red, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
