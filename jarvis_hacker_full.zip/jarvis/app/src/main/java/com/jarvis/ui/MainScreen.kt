package com.jarvis.ui

import android.content.Intent
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.data.AppDatabase
import com.jarvis.data.ExecutionLog
import com.jarvis.service.JarvisService
import kotlinx.coroutines.launch

@Composable
fun MainScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var logs by remember { mutableStateOf(listOf<ExecutionLog>()) }
    var status by remember { mutableStateOf("INITIALIZING") }
    var isServiceRunning by remember { mutableStateOf(JarvisService.isRunning) }

    LaunchedEffect(Unit) {
        val db = AppDatabase.get(context)
        db.logDao().getLogsFlow().collect { logs = it }
    }

    LaunchedEffect(Unit) {
        // Poll service status
        while (true) {
            isServiceRunning = JarvisService.isRunning
            status = if (isServiceRunning) {
                // Get wake state if possible
                "LISTENING - Say Hey Jarvis"
            } else "OFFLINE - Starting..."
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)
    ) {
        // Header
        Text("> JARVIS v1.0 // HACKER EDITION", color = HackerColors.Green, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Text("> DEVICE: Xiaomi Note 13 5G // FREE PERSONAL BUILD", color = HackerColors.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.height(12.dp))

        // Orb - Hacker type as requested
        Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            HackerOrb(status)
        }

        // Status terminal
        Column(modifier = Modifier.fillMaxWidth().background(HackerColors.Card).padding(8.dp)) {
            Text("> SYSTEM STATUS: ${if (isServiceRunning) "ONLINE" else "OFFLINE"}", color = if(isServiceRunning) HackerColors.Green else HackerColors.Red, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("> MODE: Hey Jarvis ONLY - No Tap", color = HackerColors.Cyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            Text("> WAKE ENGINE: openWakeWord FREE [no Picovoice]", color = HackerColors.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text("> ${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())} - Say 'Hey Jarvis' then command", color = HackerColors.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }

        Spacer(Modifier.height(12.dp))

        // Controls
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val intent = Intent(context, JarvisService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent) else context.startService(intent)
                },
                colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Green, contentColor = Color.Black),
                modifier = Modifier.weight(1f)
            ) {
                Text("START JARVIS", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
            Button(
                onClick = {
                    context.stopService(Intent(context, JarvisService::class.java))
                },
                colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Card, contentColor = HackerColors.Red),
                modifier = Modifier.weight(1f)
            ) {
                Text("STOP", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(Modifier.height(12.dp))

        // Activity Log - Hacker terminal
        Text("> ACTIVITY LOG // Self-healing enabled", color = HackerColors.Green, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        LazyColumn(modifier = Modifier.fillMaxWidth().height(180.dp).background(Color(0xFF0A0A0A)).padding(8.dp)) {
            items(logs.take(20)) { log ->
                val color = when(log.status) {
                    "SUCCESS" -> HackerColors.Green
                    "FAIL" -> HackerColors.Red
                    else -> HackerColors.Cyan
                }
                Text(
                    text = "[${java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(log.timestamp))}] ${log.type} | ${log.query.take(40)} | ${log.status} | ${log.durationMs}ms",
                    color = color,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                if (log.outputSnippet.isNotBlank()) {
                    Text(text = "  > ${log.outputSnippet.take(80)}", color = HackerColors.Gray, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                }
            }
            if (logs.isEmpty()) {
                item {
                    Text("> No logs yet. Say 'Hey Jarvis' to start.", color = HackerColors.Gray, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
