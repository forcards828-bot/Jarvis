package com.jarvis.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jarvis.data.SecureKeys
import com.jarvis.python.PythonRunner
import com.jarvis.util.BackupManager
import kotlinx.coroutines.launch
import java.io.File

/**
 * Settings with Upload Files option + Backups as user asked
 */
@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var geminiKey by remember { mutableStateOf(SecureKeys.getGemini(context)) }
    var ytKey by remember { mutableStateOf(SecureKeys.getYouTube(context)) }
    var tools by remember { mutableStateOf(listOf<File>()) }
    var backups by remember { mutableStateOf(listOf<BackupManager.BackupPoint>()) }
    val backupManager = remember { BackupManager(context) }
    val pythonRunner = remember { PythonRunner(context) }

    fun refresh() {
        tools = pythonRunner.listTools()
        backups = backupManager.listBackups()
    }

    LaunchedEffect(Unit) { refresh() }

    // Upload file launcher - As user requested: option to upload files
    val pickFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val input = context.contentResolver.openInputStream(uri) ?: return@launch
                    val name = getFileName(context, uri) ?: "tool_${System.currentTimeMillis()}.py"
                    val destDir = pythonRunner.getToolDir()
                    val dest = File(destDir, name)
                    // Backup before overwrite
                    if (dest.exists()) backupManager.backupFileBeforeFix(dest)
                    dest.outputStream().use { out -> input.copyTo(out) }
                    // If zip, extract
                    if (name.endsWith(".zip")) {
                        extractZip(dest, destDir)
                        dest.delete()
                    }
                    Toast.makeText(context, "Uploaded: $name", Toast.LENGTH_SHORT).show()
                    refresh()
                } catch (e: Exception) {
                    Toast.makeText(context, "Upload fail: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val pickZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val input = context.contentResolver.openInputStream(uri) ?: return@launch
                    val destDir = pythonRunner.getToolDir()
                    val tempZip = File(context.cacheDir, "import_${System.currentTimeMillis()}.zip")
                    tempZip.outputStream().use { input.copyTo(it) }
                    extractZip(tempZip, destDir)
                    Toast.makeText(context, "Zip imported", Toast.LENGTH_SHORT).show()
                    refresh()
                } catch (e: Exception) {
                    Toast.makeText(context, "Zip fail: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("> SETTINGS // JARVIS HACKER", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Text("> API Keys - Encrypted with Keystore", color = HackerColors.Gray, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
        item {
            HackerCard {
                Text("GEMINI API KEY", color = HackerColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                OutlinedTextField(value = geminiKey, onValueChange = { geminiKey = it }, label = { Text("Gemini Key", fontSize=10.sp) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
                Text("YOUTUBE API KEY", color = HackerColors.Cyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                OutlinedTextField(value = ytKey, onValueChange = { ytKey = it }, label = { Text("YouTube Key", fontSize=10.sp) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    SecureKeys.saveGemini(context, geminiKey)
                    SecureKeys.saveYouTube(context, ytKey)
                    Toast.makeText(context, "Keys saved encrypted", Toast.LENGTH_SHORT).show()
                }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Green, contentColor = Color.Black)) {
                    Text("SAVE KEYS ENCRYPTED", fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }
        item {
            Text("> UPLOAD PYTHON TOOLS // As you asked", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            HackerCard {
                Text("Upload .py file or .zip project. Tools run with self-healing.", color = HackerColors.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { pickFileLauncher.launch("*/*") }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Card, contentColor = HackerColors.Green)) {
                        Text("UPLOAD FILE", fontSize=10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = { pickZipLauncher.launch("application/zip") }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Card, contentColor = HackerColors.Cyan)) {
                        Text("UPLOAD ZIP", fontSize=10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Installed Tools (${tools.size}):", color = HackerColors.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                tools.forEach { f ->
                    Text("> ${f.name} [${f.length()/1024}KB]", color = HackerColors.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        item {
            Text("> BACKUPS // So nothing fails", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            HackerCard {
                Text("Auto-backup before every fix & service start", color = HackerColors.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { backupManager.createBackup("manual"); refresh() } }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Green, contentColor = Color.Black)) {
                        Text("CREATE BACKUP NOW", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(onClick = { scope.launch { val ok = backupManager.restoreLatest(); Toast.makeText(context, if(ok) "Restored latest" else "No backup", Toast.LENGTH_SHORT).show(); refresh() } }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Card)) {
                        Text("RESTORE LATEST", fontSize=10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Backup Points:", color = HackerColors.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                backups.take(5).forEach { b ->
                    Text("> ${b.name} | ${b.time}", color = HackerColors.White, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
        item {
            Text("> XIAOMI NOTE 13 5G CHECKLIST", color = HackerColors.Green, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            HackerCard {
                Button(onClick = {
                    try {
                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
                    } catch (_: Exception) {}
                }, colors = ButtonDefaults.buttonColors(containerColor = HackerColors.Card)) {
                    Text("OPEN APP INFO - ENABLE AUTOSTART + NO RESTRICTIONS", fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(Modifier.height(4.dp))
                Text("1. Autostart = ON\n2. Battery Saver = No Restrictions\n3. Lock App in Recents\n4. Allow All Permissions", color = HackerColors.Gray, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun HackerCard(content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().border(1.dp, HackerColors.Green.copy(alpha=0.3f)).background(HackerColors.Card).padding(12.dp), content = content)
}

fun getFileName(context: android.content.Context, uri: Uri): String? {
    return try {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) it.getString(idx) else null
            } else null
        }
    } catch (_: Exception) { null }
}

fun extractZip(zipFile: File, destDir: File) {
    try {
        java.util.zip.ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val newFile = File(destDir, entry.name)
                if (entry.isDirectory) newFile.mkdirs()
                else {
                    newFile.parentFile?.mkdirs()
                    newFile.outputStream().use { zis.copyTo(it) }
                }
                entry = zis.nextEntry
            }
        }
    } catch (e: Exception) { e.printStackTrace() }
}
