package com.jarvis.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

@Composable
fun HackerOrb(state: String, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(
        initialValue = 0.8f, targetValue = 1.2f,
        animationSpec = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val rotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing), RepeatMode.Restart),
        label = "rot"
    )
    val glowAlpha by infinite.animateFloat(
        initialValue = 0.3f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
        label = "glow"
    )

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(200.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = this.center
                val radius = size.minDimension / 3 * pulse

                // Outer glow
                drawCircle(
                    color = HackerColors.Green.copy(alpha = glowAlpha * 0.2f),
                    radius = radius * 1.5f,
                    center = center
                )
                // Main orb
                drawCircle(
                    color = HackerColors.Green.copy(alpha = 0.15f),
                    radius = radius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )
                // Inner waveform rings
                for (i in 0..2) {
                    val r = radius * (0.6f + i * 0.15f + sin(rotation/50 + i) * 0.05f)
                    drawCircle(
                        color = HackerColors.Green.copy(alpha = 0.6f - i*0.15f),
                        radius = r,
                        center = center,
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
                // Rotating ticks
                for (angle in 0 until 360 step 30) {
                    val rad = Math.toRadians((angle + rotation).toDouble())
                    val x1 = center.x + kotlin.math.cos(rad) * radius * 0.7
                    val y1 = center.y + kotlin.math.sin(rad) * radius * 0.7
                    val x2 = center.x + kotlin.math.cos(rad) * radius * 1.1
                    val y2 = center.y + kotlin.math.sin(rad) * radius * 1.1
                    drawLine(
                        color = HackerColors.Green,
                        start = androidx.compose.ui.geometry.Offset(x1.toFloat(), y1.toFloat()),
                        end = androidx.compose.ui.geometry.Offset(x2.toFloat(), y2.toFloat()),
                        strokeWidth = 2f
                    )
                }
            }
            Text(
                text = when(state) {
                    "LISTENING" -> "◉ LISTENING"
                    "THINKING" -> "◉ THINKING"
                    "SEARCHING" -> "◉ SEARCHING"
                    "SPEAKING" -> "◉ SPEAKING"
                    "ERROR" -> "◉ ERROR"
                    else -> "JARVIS ONLINE"
                },
                color = HackerColors.Green,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = "> $state...",
            color = HackerColors.GreenDim,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
