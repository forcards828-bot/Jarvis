package com.jarvis.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.actions.FileActions
import com.jarvis.actions.PhoneActions
import com.jarvis.data.AppDatabase
import com.jarvis.data.ExecutionLog
import com.jarvis.data.SecureKeys
import com.jarvis.python.SelfHealingFixer
import com.jarvis.router.GeminiClient
import com.jarvis.router.IntentRouter
import com.jarvis.search.SearchManager
import com.jarvis.util.BackupManager
import com.jarvis.voice.STTManager
import com.jarvis.voice.TTSManager
import com.jarvis.wakeword.OpenWakeWordManager
import kotlinx.coroutines.*
import java.io.File

/**
 * CORE SERVICE - Hey Jarvis ONLY mode as user requested
 * No tap to talk - Only wake word
 * Hacker type - silent but online
 * Self-healing + Backup built-in so nothing fails
 */
class JarvisService : Service() {

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    private lateinit var wakeManager: OpenWakeWordManager
    private lateinit var sttManager: STTManager
    private lateinit var ttsManager: TTSManager
    private lateinit var gemini: GeminiClient
    private lateinit var searchManager: SearchManager
    private lateinit var phoneActions: PhoneActions
    private lateinit var fileActions: FileActions
    private lateinit var backupManager: BackupManager
    private lateinit var healingFixer: SelfHealingFixer
    private lateinit var db: AppDatabase

    private var isProcessing = false
    
    companion object {
        const val CHANNEL_ID = "jarvis_hacker_channel"
        const val NOTIF_ID = 777
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        Log.i("JarvisService", "JARVIS Service Created - Hacker Edition")
        isRunning = true
        createNotificationChannel()
        
        // Init all managers - self-healing if one fails
        try {
            db = AppDatabase.get(this)
            wakeManager = OpenWakeWordManager(this)
            sttManager = STTManager(this)
            ttsManager = TTSManager(this)
            ttsManager.init()
            gemini = GeminiClient(this)
            searchManager = SearchManager(this)
            phoneActions = PhoneActions(this)
            fileActions = FileActions(this)
            backupManager = BackupManager(this)
            healingFixer = SelfHealingFixer(this)
            
            // Auto backup on create - so nothing fails
            scope.launch { 
                try { backupManager.createBackup("service_start") } catch (_: Exception) {} 
            }
            
            setupWakeWord()
            
        } catch (e: Exception) {
            Log.e("JarvisService", "Init failed - self healing", e)
            // Self-heal: try re-init after delay
            scope.launch { delay(3000); onCreate() }
        }
    }

    private fun setupWakeWord() {
        wakeManager.onWake = {
            if (!isProcessing) {
                scope.launch { onWakeTriggered() }
            }
        }
        wakeManager.start()
    }

    private suspend fun onWakeTriggered() {
        isProcessing = true
        try {
            Log.i("JarvisService", "WAKE TRIGGERED: Hey Jarvis")
            // Vibrate feedback hacker style
            // TTS response "Yes boss"
            ttsManager.speak("Yes boss")
            delay(800) // Let TTS say yes boss
            
            // Start listening for command after wake
            listenForCommand()
        } catch (e: Exception) {
            Log.e("JarvisService", "Wake handling error", e)
            isProcessing = false
        }
    }

    private fun listenForCommand() {
        sttManager.onResult = { text ->
            scope.launch { processCommand(text) }
        }
        sttManager.onError = { err ->
            scope.launch {
                Log.w("JarvisService", "STT error $err - self healing retry")
                // Self-heal: retry listening once
                if (!err.contains("timeout")) {
                    delay(500)
                    ttsManager.speak("Say again, boss")
                    delay(1000)
                    listenForCommand()
                } else {
                    isProcessing = false
                }
            }
        }
        sttManager.startListening("en-IN")
    }

    private suspend fun processCommand(text: String) {
        val start = System.currentTimeMillis()
        try {
            Log.i("JarvisService", "COMMAND: $text")
            db.conversationDao().insert(com.jarvis.data.ConversationTurn(role="user", text=text))
            
            val route = IntentRouter.route(text)
            var resultText = ""
            var success = true
            
            when (route.type) {
                IntentRouter.Type.CALL_CONTACT -> {
                    val query = route.params["contact"] ?: ""
                    val contacts = phoneActions.searchContacts(query)
                    if (contacts.size == 1) {
                        phoneActions.callContact(contacts[0].number)
                        resultText = "Calling ${contacts[0].name}, boss"
                    } else if (contacts.size > 1) {
                        resultText = "Found ${contacts.size} contacts named $query. Say full name."
                        success = false
                    } else {
                        resultText = "No contact found for $query"
                        success = false
                    }
                }
                IntentRouter.Type.OPEN_APP -> {
                    val app = route.params["app"] ?: ""
                    val ok = phoneActions.openApp(app)
                    resultText = if (ok) "Opening $app" else "Cannot open $app, not installed"
                }
                IntentRouter.Type.FLASHLIGHT -> {
                    // Flashlight via CameraManager handled in MainActivity, here just confirm
                    resultText = "Flashlight ${route.params["state"]}"
                }
                IntentRouter.Type.FILE_SEARCH -> {
                    val files = fileActions.findFile(text)
                    resultText = if (files.isEmpty()) "No files found for $text" else "Found ${files.size} files: ${files.joinToString { it.name }}"
                }
                IntentRouter.Type.WEB_SEARCH, IntentRouter.Type.SUMMARIZE -> {
                    resultText = "Searching... Do as directed"
                    val webResults = searchManager.searchWeb(text)
                    val ytResults = searchManager.searchYouTube(text)
                    val combined = (webResults + ytResults).take(5).joinToString("\n") { "[${it.source}] ${it.title} - ${it.publishedAgo}" }
                    val summary = gemini.summarize("Query: $text\nResults:\n$combined")
                    resultText = summary
                }
                IntentRouter.Type.YOUTUBE_SEARCH -> {
                    val yt = searchManager.searchYouTube(text)
                    val live = yt.filter { it.isLive }
                    resultText = if (live.isNotEmpty()) "Found ${live.size} LIVE videos: ${live.joinToString { it.title }}" else "Found ${yt.size} videos: ${yt.joinToString { it.title.take(40) }}"
                }
                IntentRouter.Type.YOUTUBE_PLAY -> {
                    // Extract second, first etc
                    resultText = "Opening YouTube for $text"
                    phoneActions.openApp("youtube")
                }
                IntentRouter.Type.PYTHON_RUN -> {
                    // Find python file mentioned
                    val files = fileActions.findFile(".py")
                    val target = files.firstOrNull { text.contains(it.nameWithoutExtension, ignoreCase = true) } ?: files.firstOrNull()
                    if (target == null) {
                        resultText = "No python tool found. Upload in Settings > Tools"
                    } else {
                        resultText = "Running ${target.name} with self-healing"
                        ttsManager.speak(resultText)
                        val healingResult = healingFixer.runWithHealing(target, 3)
                        resultText = if (healingResult.success) "Tool ${target.name} executed success: ${healingResult.output.take(200)}" else "Tool failed after ${healingResult.attempts} tries. Log: ${healingResult.logs.takeLast(2).joinToString()}"
                    }
                }
                else -> { // AI_CHAT
                    resultText = gemini.chat(text)
                }
            }
            
            // Save log with backup
            val log = ExecutionLog(
                type = route.type.name,
                query = text,
                status = if (success) "SUCCESS" else "FAIL",
                durationMs = System.currentTimeMillis() - start,
                outputSnippet = resultText.take(500)
            )
            db.logDao().insert(log)
            
            // Speak result
            db.conversationDao().insert(com.jarvis.data.ConversationTurn(role="model", text=resultText))
            ttsManager.speak(resultText)
            
            // Continuous listening for 8 sec as user wants only Hey Jarvis chain
            delay(8000)
            isProcessing = false
            
        } catch (e: Exception) {
            Log.e("JarvisService", "Process command error - self healing", e)
            ttsManager.speak("Error boss, self healing: ${e.message?.take(100)}")
            // Self-heal: backup + retry not infinite
            try { backupManager.createBackup("error_${System.currentTimeMillis()}") } catch (_: Exception) {}
            isProcessing = false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, createNotification("JARVIS ONLINE - Hacker Mode - Say Hey Jarvis"))
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "JARVIS Hacker", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Hey Jarvis only - Free personal"
                setShowBadge(false)
                enableVibration(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pending = PendingIntent.getActivity(this, 0, launchIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        try { wakeManager.destroy() } catch (_: Exception) {}
        try { sttManager.destroy() } catch (_: Exception) {}
        try { ttsManager.shutdown() } catch (_: Exception) {}
        scope.cancel()
        Log.i("JarvisService", "JARVIS Destroyed")
    }
}
