package com.jarvis.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.*

class TTSManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking
    private var initialized = false

    private val _state = MutableStateFlow("IDLE")
    val state: StateFlow<String> = _state

    fun init(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Try en-IN first for Indian accent, fallback to en-US
                var result = tts?.setLanguage(Locale.forLanguageTag("en-IN"))
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    result = tts?.setLanguage(Locale.forLanguageTag("hi-IN"))
                }
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
                tts?.setSpeechRate(1.0f)
                tts?.setPitch(1.0f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { _isSpeaking.value = true; _state.value = "SPEAKING" }
                    override fun onDone(id: String?) { _isSpeaking.value = false; _state.value = "IDLE" }
                    override fun onError(id: String?) { _isSpeaking.value = false; _state.value = "ERROR"; Log.e("JarvisTTS","TTS error") }
                })
                initialized = true
                onReady()
                Log.i("JarvisTTS","TTS ready")
            }
        }
    }

    fun speak(text: String, interrupt: Boolean = true) {
        if (!initialized) { init { speak(text, interrupt) }; return }
        if (interrupt) stop()
        _state.value = "SPEAKING"
        val clean = text.take(4000) // Android TTS limit
        tts?.speak(clean, if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
    }

    fun stop() {
        try { tts?.stop() } catch (_: Exception) {}
        _isSpeaking.value = false
        _state.value = "IDLE"
    }

    fun shutdown() {
        stop()
        try { tts?.shutdown() } catch (_: Exception) {}
    }
}
