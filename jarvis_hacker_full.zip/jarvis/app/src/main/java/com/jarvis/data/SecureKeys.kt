package com.jarvis.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.jarvis.BuildConfig

object SecureKeys {
    private const val PREF_NAME = "jarvis_encrypted_keys"
    private const val KEY_GEMINI = "gemini_key"
    private const val KEY_YOUTUBE = "youtube_key"
    
    // Hardcoded from BuildConfig for first launch, then encrypted storage takes over
    // This is personal sideload, not Play Store, so acceptable
    val DEFAULT_GEMINI = BuildConfig.GEMINI_API_KEY
    val DEFAULT_YOUTUBE = BuildConfig.YOUTUBE_API_KEY

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        PREF_NAME,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getGemini(context: Context): String {
        val p = prefs(context)
        val stored = p.getString(KEY_GEMINI, null)
        if (!stored.isNullOrBlank()) return stored
        // First launch: save BuildConfig to encrypted storage
        if (DEFAULT_GEMINI.isNotBlank()) {
            saveGemini(context, DEFAULT_GEMINI)
            return DEFAULT_GEMINI
        }
        return ""
    }

    fun saveGemini(context: Context, key: String) {
        prefs(context).edit().putString(KEY_GEMINI, key).apply()
    }

    fun getYouTube(context: Context): String {
        val p = prefs(context)
        val stored = p.getString(KEY_YOUTUBE, null)
        if (!stored.isNullOrBlank()) return stored
        if (DEFAULT_YOUTUBE.isNotBlank()) {
            saveYouTube(context, DEFAULT_YOUTUBE)
            return DEFAULT_YOUTUBE
        }
        return ""
    }

    fun saveYouTube(context: Context, key: String) {
        prefs(context).edit().putString(KEY_YOUTUBE, key).apply()
    }

    fun hasKeys(context: Context): Boolean = getGemini(context).isNotBlank()
}
