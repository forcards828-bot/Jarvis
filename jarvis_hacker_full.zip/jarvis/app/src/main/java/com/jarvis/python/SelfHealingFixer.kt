package com.jarvis.python

import android.content.Context
import android.util.Log
import com.jarvis.router.GeminiClient
import com.jarvis.util.BackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Self-healing Python runner as user requested:
 * - Sees error
 * - Backups original (so nothing fails)
 * - Fixes via Gemini
 * - Retries up to 3 times
 * - Self-tests
 */
class SelfHealingFixer(private val context: Context) {

    private val runner = PythonRunner(context)
    private val gemini = GeminiClient(context)
    private val backup = BackupManager(context)

    data class HealingResult(
        val success: Boolean,
        val finalFile: File,
        val originalBackup: File?,
        val attempts: Int,
        val logs: List<String>,
        val output: String
    )

    suspend fun runWithHealing(target: File, maxAttempts: Int = 3): HealingResult = withContext(Dispatchers.IO) {
        val logs = mutableListOf<String>()
        var currentFile = target
        var originalBackup: File? = null
        var attempts = 0
        var lastOutput = ""

        try {
            // Backup original first - so nothing fails
            if (originalBackup == null) {
                originalBackup = backup.backupFileBeforeFix(target)
                logs.add("BACKUP CREATED: ${originalBackup.name}")
            }

            while (attempts < maxAttempts) {
                attempts++
                logs.add("ATTEMPT $attempts: Running ${currentFile.name}")

                // Self-test 1: syntax check
                val syntaxCheck = selfTestSyntax(currentFile)
                if (!syntaxCheck.first) {
                    logs.add("SELF-TEST FAIL: ${syntaxCheck.second}")
                } else {
                    logs.add("SELF-TEST PASS: syntax ok")
                }

                val result = runner.runFile(currentFile)
                lastOutput = result.output

                if (result.success) {
                    logs.add("SUCCESS on attempt $attempts in ${result.durationMs}ms")
                    return@withContext HealingResult(true, currentFile, originalBackup, attempts, logs, result.output)
                }

                logs.add("ERROR: ${result.error.take(500)}")
                
                if (attempts >= maxAttempts) break

                // Try auto-fix via Gemini
                logs.add("HEALING: Asking Gemini to fix...")
                try {
                    val code = currentFile.readText()
                    val fixedCode = gemini.fixPython(code, result.error)
                    
                    if (fixedCode.isBlank() || fixedCode == code) {
                        logs.add("HEALING FAIL: Gemini returned empty or same code")
                        // Try to create fixed file with safe fallback?
                    } else {
                        // Backup current before overwrite
                        backup.backupFileBeforeFix(currentFile)
                        
                        val fixedFile = File(currentFile.parent, "${currentFile.nameWithoutExtension}_fixed_v$attempts.py")
                        fixedFile.writeText(fixedCode)
                        logs.add("HEALING: Created ${fixedFile.name}")
                        
                        // Self-test fixed file
                        val testFix = selfTestSyntax(fixedFile)
                        if (!testFix.first) {
                            logs.add("FIX SELF-TEST FAIL: ${testFix.second} - still trying to run")
                        }
                        
                        currentFile = fixedFile
                    }
                } catch (e: Exception) {
                    logs.add("HEALING EXCEPTION: ${e.message}")
                    Log.e("JarvisHealing", "Fix failed", e)
                }
            }

            logs.add("FAILED after $attempts attempts - Restoring is possible from backup")
            HealingResult(false, currentFile, originalBackup, attempts, logs, lastOutput)

        } catch (e: Exception) {
            logs.add("CRITICAL FAIL: ${e.message}")
            HealingResult(false, currentFile, originalBackup, attempts, logs, e.message ?: "")
        }
    }

    private fun selfTestSyntax(file: File): Pair<Boolean, String> {
        return try {
            val code = file.readText()
            if (code.isBlank()) return false to "Empty file"
            // Basic python syntax checks
            var openParen = 0
            var openBracket = 0
            code.forEach { c ->
                when(c) { '(' -> openParen++; ')' -> openParen--; '[' -> openBracket++; ']' -> openBracket-- }
            }
            if (openParen != 0) return false to "Mismatched parentheses"
            if (openBracket != 0) return false to "Mismatched brackets"
            // Check for dangerous ops for personal safety - still allow but warn
            if (code.contains("os.system") && code.contains("rm -rf")) return false to "Dangerous rm -rf detected"
            true to "ok"
        } catch (e: Exception) {
            false to (e.message ?: "unknown syntax error")
        }
    }
}
