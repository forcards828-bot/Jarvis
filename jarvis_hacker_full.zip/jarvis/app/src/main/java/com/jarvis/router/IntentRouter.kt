package com.jarvis.router

import android.util.Log

/**
 * FREE Local Router - Saves Gemini quota
 * Runs on-device regex + keywords before calling AI
 */
object IntentRouter {

    data class Route(
        val type: Type,
        val confidence: Float,
        val params: Map<String, String> = emptyMap(),
        val original: String
    )

    enum class Type {
        CALL_CONTACT,
        OPEN_APP,
        FLASHLIGHT,
        ALARM,
        TIMER,
        NAVIGATE,
        FILE_SEARCH,
        FILE_READ,
        WEB_SEARCH,
        YOUTUBE_SEARCH,
        YOUTUBE_PLAY,
        PYTHON_RUN,
        SUMMARIZE,
        AI_CHAT,
        UNKNOWN
    }

    fun route(text: String): Route {
        val t = text.lowercase().trim()
        Log.d("JarvisRouter", "Routing: $t")

        // Summarize / Do as Directed - as user asked
        if (t.contains("do as directed") || t.contains("summarize") || t.contains("summary") || t.contains("brief me")) {
            return Route(Type.SUMMARIZE, 0.95f, mapOf("query" to text), text)
        }

        // Call
        val callRegex = Regex("(call|phone|dial)\\s+(.+)", RegexOption.IGNORE_CASE)
        callRegex.find(text)?.let {
            return Route(Type.CALL_CONTACT, 0.98f, mapOf("contact" to it.groupValues[2].trim()), text)
        }
        if (t.startsWith("call ")) return Route(Type.CALL_CONTACT, 0.9f, mapOf("contact" to text.removePrefix("call ").trim()), text)

        // Open app
        val openRegex = Regex("(open|launch|start)\\s+(.+)", RegexOption.IGNORE_CASE)
        openRegex.find(text)?.let {
            val app = it.groupValues[2].trim()
            if (listOf("youtube", "instagram", "chrome", "maps", "spotify", "whatsapp", "gmail", "camera", "settings").any { app.contains(it) }) {
                return Route(Type.OPEN_APP, 0.95f, mapOf("app" to app), text)
            }
        }

        // Flashlight
        if (t.contains("flashlight") || t.contains("torch") || t.contains("flash light")) {
            val on = !t.contains("off")
            return Route(Type.FLASHLIGHT, 0.97f, mapOf("state" to if (on) "on" else "off"), text)
        }

        // File
        if (t.contains("find file") || t.contains("search file") || t.contains("my file") || t.contains(".pdf") || t.contains(".txt")) {
            return Route(Type.FILE_SEARCH, 0.85f, mapOf("query" to text), text)
        }
        if (t.contains("read file") || t.contains("open file")) {
            return Route(Type.FILE_READ, 0.85f, mapOf("file" to text), text)
        }

        // YouTube
        if (t.contains("youtube") || t.contains("video") || t.contains("live video") || t.contains("stream")) {
            if (t.contains("play") && (t.contains("second") || t.contains("first") || t.contains("this") || t.contains("live"))) {
                return Route(Type.YOUTUBE_PLAY, 0.9f, mapOf("query" to text), text)
            }
            return Route(Type.YOUTUBE_SEARCH, 0.9f, mapOf("query" to text), text)
        }

        // Python
        if (t.contains("run python") || t.contains("run tool") || t.contains("execute tool") || t.contains("import tool") || t.contains(".py")) {
            return Route(Type.PYTHON_RUN, 0.92f, mapOf("file" to text), text)
        }

        // Web search triggers
        val searchTriggers = listOf("latest", "news", "what is happening", "current", "today", "breaking", "updates", "search")
        if (searchTriggers.any { t.contains(it) }) {
            return Route(Type.WEB_SEARCH, 0.8f, mapOf("query" to text), text)
        }

        // Default to AI chat - will use Gemini
        return Route(Type.AI_CHAT, 0.6f, mapOf("query" to text), text)
    }
}
