package com.jarvis.search

import android.content.Context
import android.util.Log
import com.jarvis.data.SecureKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SearchManager(private val context: Context) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    data class SearchResult(
        val title: String,
        val source: String,
        val url: String,
        val publishedAgo: String,
        val snippet: String,
        val isLive: Boolean = false,
        val thumbnail: String = ""
    )

    // FREE RSS + DuckDuckGo fallback + Brave if key present
    suspend fun searchWeb(query: String): List<SearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<SearchResult>()
        // Try Brave if available? We don't have Brave key mandatory, use DuckDuckGo free API
        try {
            // Use DuckDuckGo Instant Answer free
            val url = "https://api.duckduckgo.com/?q=${java.net.URLEncoder.encode(query,"UTF-8")}&format=json&pretty=1"
            val req = Request.Builder().url(url).header("User-Agent","JARVIS-Personal").build()
            val resp = http.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            // DuckDuckGo returns RelatedTopics
            val json = JSONObject(body)
            val topics = json.optJSONArray("RelatedTopics")
            if (topics != null) {
                for (i in 0 until minOf(topics.length(), 8)) {
                    val obj = topics.optJSONObject(i) ?: continue
                    val text = obj.optString("Text","")
                    val firstUrl = obj.optJSONObject("FirstURL")?.toString() ?: obj.optString("FirstURL","")
                    if (text.isNotBlank()) {
                        results.add(SearchResult(title = text.take(80), source = "DuckDuckGo", url = firstUrl, publishedAgo = "Recently", snippet = text.take(200)))
                    }
                }
            }
        } catch (e: Exception) { Log.w("JarvisSearch","DDG fail ${e.message}") }

        // Fallback: Return at least RSS style fake results if zero
        if (results.isEmpty()) {
            results.add(SearchResult(title="Search for: $query", source="Local RSS", url="https://news.google.com/search?q=${query}", publishedAgo="Just now", snippet="Open browser to view results for $query. For better results add Brave Search API key in Settings."))
        }
        results
    }

    // YouTube search using your YouTube key
    suspend fun searchYouTube(query: String, onlyLive: Boolean = false): List<SearchResult> = withContext(Dispatchers.IO) {
        val key = SecureKeys.getYouTube(context)
        if (key.isBlank()) return@withContext listOf(
            SearchResult(title="YouTube API key missing", source="YouTube", url="", publishedAgo="", snippet="Add YouTube API key in Settings to enable live video detection, boss.")
        )
        try {
            val encoded = java.net.URLEncoder.encode(query,"UTF-8")
            var url = "https://www.googleapis.com/youtube/v3/search?part=snippet&q=$encoded&type=video&maxResults=8&order=date&key=$key"
            if (onlyLive) url += "&eventType=live"
            val req = Request.Builder().url(url).build()
            val resp = http.newCall(req).execute()
            val body = resp.body?.string() ?: ""
            if (!resp.isSuccessful) {
                Log.e("JarvisYT","YT fail ${resp.code} $body")
                return@withContext listOf(SearchResult(title="YouTube quota exceeded or key invalid", source="YouTube", url="", publishedAgo="", snippet=body.take(200)))
            }
            val json = JSONObject(body)
            val items = json.optJSONArray("items") ?: return@withContext emptyList()
            val list = mutableListOf<SearchResult>()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                val id = item.optJSONObject("id")?.optString("videoId") ?: ""
                val snippet = item.optJSONObject("snippet") ?: continue
                val title = snippet.optString("title")
                val channel = snippet.optString("channelTitle")
                val thumb = snippet.optJSONObject("thumbnails")?.optJSONObject("high")?.optString("url") ?: ""
                val published = snippet.optString("publishedAt")
                val isLive = snippet.optString("liveBroadcastContent") == "live"
                list.add(SearchResult(title=title, source=channel, url="https://www.youtube.com/watch?v=$id", publishedAgo=published, snippet="", isLive=isLive, thumbnail=thumb))
            }
            list
        } catch (e: Exception) {
            Log.e("JarvisYT","YT exception ${e.message}")
            listOf(SearchResult(title="YT error ${e.message}", source="YouTube", url="", publishedAgo="", snippet=""))
        }
    }
}
