# JARVIS - Personal Free Build for Xiaomi Note 13 5G
# 100% Free, Personal Sideload, No Play Store, OpenWakeWord

## This is your ALL-IN-ONE build
- Wake Word: Sherpa-ONNX / openWakeWord `hey jarvis` - FREE, OFFLINE, NO API KEY
- STT: Android SpeechRecognizer free (en-IN, hi-IN)
- TTS: Android TextToSpeech free
- Router: On-device regex + Gemini Flash free
- Phone Actions: Call, Open App, Flashlight, Alarm, Files, Contacts
- Search: RSS (free unlimited) + Brave optional + YouTube Data API
- Python: Chaquopy + Self-Healing auto-fix with Gemini
- UI: Jetpack Compose Premium Orb

## API Keys - Stored ONLY on your phone
Your keys are in `local.properties` and injected via BuildConfig, then encrypted with Android Keystore at runtime.
- Gemini: For thinking + fixing python
- YouTube: For live video detection

You must NOT share this APK publicly because it contains your keys in encrypted form.

## How to Build APK on your PC (5 mins)

1. Install Android Studio Ladybug or newer
2. Open folder `jarvis/` in Android Studio
3. Let it sync gradle
4. Connect Xiaomi Note 13 5G via USB, enable Developer Options + USB Debugging
5. Run: Build -> Build APK(s) -> Debug
6. APK at: `app/build/outputs/apk/debug/app-debug.apk`

Alternatively in terminal:
```bash
./gradlew assembleDebug
```

## Xiaomi Note 13 5G Setup After Install (IMPORTANT)

1. Install APK
2. Open App Info -> Permissions -> Allow: Microphone, Contacts, Phone, Files, Notifications, Alarms
3. App Info -> Autostart -> Enable
4. App Info -> Battery Saver -> No Restrictions
5. Recent Apps -> Find Jarvis -> Long press / Tap 3 dots -> Lock App (so HyperOS doesn't kill)
6. Open Jarvis -> Settings -> Paste your API keys again to encrypt them (first launch auto-imports from BuildConfig)
7. Settings -> Battery Check -> Should show all Green

If HyperOS still kills: Settings -> Battery -> Additional Settings -> Turn off "Close background apps" optimization.

## Usage
- Tap orb to talk, or say "Hey Jarvis" when screen is ON
- When screen OFF, use notification button to talk (Xiaomi kills mic otherwise)
- Say: "Call Rahul", "Open YouTube", "Find file resume.pdf", "What's latest AI news", "Play live video", "Run python tool"
- Settings -> Tools -> Import zip

## Python Tools
Upload zip with:
- main.py
- requirements.txt (only pure python - requests, bs4, etc.)
- jarvis.json {"name":"My Tool","entry":"main.py","permissions":["internet"]}

## Security - Personal Only
- Keys stored in EncryptedSharedPreferences + Keystore
- Python tools sandboxed to app/files/tools/
- No file outside sandbox without permission
- No internet for tools unless declared

Built as per your request: Personal + Free + Xiaomi + Option A - openWakeWord
